./gapminer -o gap.suprnova.cc -p 2433 -u mihaiflorin404.cpu -x 1234 --stratum --use-cpu --platform arm -d 1 -e -j 2 -t 8
